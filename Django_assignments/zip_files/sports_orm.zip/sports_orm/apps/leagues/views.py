from django.shortcuts import render, redirect
from .models import League, Team, Player

from django.db.models import Q # needed for an "OR" statement (see last example below from context dict)

from . import team_maker

def index(request):
	context = {
		# all leagues
		"leagues": League.objects.all(),
		# all teams
		"teams": Team.objects.all(),
		# all players
		"players": Player.objects.all(),
		# ...all baseball leagues
		"baseball_leagues":League.objects.all().filter(sport="Baseball"),
		# ...all womens' leagues
		"womens_leagues":League.objects.all().filter(name__contains="Women"),
		# ...all leagues where sport is any type of hockey
		"hockey_leagues":League.objects.all().filter(sport__contains="Hockey"),
		# ...all leagues where sport is something OTHER THAN football
		"not_football_leagues":League.objects.all().exclude(sport__contains="Football"),
		# ...all leagues that call themselves "conferences"
		"conference_leagues":League.objects.all().filter(name__contains="Conference"),
		# ...all leagues in the Atlantic region
		"atlantic_leagues":League.objects.all().filter(name__contains="Atlantic"),
		# ...all teams based in Dallas
		"dallas_teams":Team.objects.all().filter(location="Dallas"),
		# ...all teams named the Raptors
		"raptors_teams":Team.objects.all().filter(team_name__contains="Raptor"),
		# ...all teams whose location includes "City"
		"city_teams":Team.objects.all().filter(location__contains="City"),
		# ...all teams whose names begin with "T"
		"t_teams":Team.objects.all().filter(team_name__startswith="T"),
		# ...all teams, ordered alphabetically by location
		"ordered_teams":Team.objects.all().order_by("location"),
		# ...all teams, ordered by team name in reverse alphabetical order
		"reverse_ordered_teams":Team.objects.all().order_by("-location"),
		# ...every player with last name "Cooper"
		"cooper_players":Player.objects.all().filter(last_name="Cooper"),
		# ...every player with first name "Joshua"
		"joshua_players":Player.objects.all().filter(first_name="Joshua"),
		# ...every player with last name "Cooper" EXCEPT FOR Joshua
		"cooper_not_joshua_players":Player.objects.all().filter(last_name="Cooper").exclude(first_name="Joshua"),
		# ...all players with first name "Alexander" OR first name "Wyatt"
		"alexander_or_wyatt_players":Player.objects.all().filter(Q(first_name="Alexander") | Q(first_name="Wyatt")),
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")







