from django.shortcuts import render, redirect
from .models import League, Team, Player

from django.db.models import Q, Count # needed for an "OR" statement (see last example below from context dict)

from . import team_maker

def index(request):
	context = {
		# all leagues
		"leagues": League.objects.all(),
		# all teams
		"teams": Team.objects.all(),
		# all players
		"players": Player.objects.all(),

		# SPORTS ORM ASSIGNENT PART I
		# ...all baseball leagues
		"baseball_leagues":League.objects.filter(sport="Baseball"),
		# ...all womens' leagues
		"womens_leagues":League.objects.filter(name__contains="Women"),
		# ...all leagues where sport is any type of hockey
		"hockey_leagues":League.objects.filter(sport__contains="Hockey"),
		# ...all leagues where sport is something OTHER THAN football
		"not_football_leagues":League.objects.exclude(sport__contains="Football"),
		# ...all leagues that call themselves "conferences"
		"conference_leagues":League.objects.filter(name__contains="Conference"),
		# ...all leagues in the Atlantic region
		"atlantic_leagues":League.objects.filter(name__contains="Atlantic"),
		# ...all teams based in Dallas
		"dallas_teams":Team.objects.filter(location="Dallas"),
		# ...all teams named the Raptors
		"raptors_teams":Team.objects.filter(team_name__contains="Raptor"),
		# ...all teams whose location includes "City"
		"city_teams":Team.objects.filter(location__contains="City"),
		# ...all teams whose names begin with "T"
		"t_teams":Team.objects.filter(team_name__startswith="T"),
		# ...all teams, ordered alphabetically by location
		"ordered_teams":Team.objects.order_by("location"),
		# ...all teams, ordered by team name in reverse alphabetical order
		"reverse_ordered_teams":Team.objects.order_by("-location"),
		# ...every player with last name "Cooper"
		"cooper_players":Player.objects.filter(last_name="Cooper"),
		# ...every player with first name "Joshua"
		"joshua_players":Player.objects.filter(first_name="Joshua"),
		# ...every player with last name "Cooper" EXCEPT FOR Joshua
		"cooper_not_joshua_players":Player.objects.filter(last_name="Cooper").exclude(first_name="Joshua"),
		# ...all players with first name "Alexander" OR first name "Wyatt"
		"alexander_or_wyatt_players":Player.objects.filter(Q(first_name="Alexander") | Q(first_name="Wyatt")),

		# SPORTS ORM ASSIGNMENT PART II
		# ...all teams in the Atlantic Soccer Conference
		"atlantic_soccer_teams":Team.objects.filter(league__in=(League.objects.filter(name__contains="Atlantic", sport="Soccer"))),
		# ...all (current) players on the Boston Penguins
		"current_penguin_players":Player.objects.filter(curr_team__in=(Team.objects.filter(team_name="Penguins", location="Boston"))),
		# ...all (current) players in the International Collegiate Baseball Conference
		"current_icbc_players":Player.objects.filter(curr_team__in=(Team.objects.filter(league__in=(League.objects.filter(name="International Collegiate Baseball Conference"))))),
		# ...all (current) players in the American Conference of Amateur Football with last name "Lopez"
		"current_acaf_lopez_players":Player.objects.filter(last_name="Lopez",curr_team__in=(Team.objects.filter(league__in=(League.objects.filter(name="American Conference of Amateur Football"))))),
		# ...all football players
		"football_players":Player.objects.filter(all_teams__in=(Team.objects.filter(league__in=(League.objects.filter(sport="Football"))))),
		# ...all teams with a (current) player named "Sophia"
		"current_sophia_teams":Team.objects.filter(id__in=(Player.objects.filter(first_name="Sophia").values("curr_team"))),
		# ...all leagues with a (current) player named "Sophia"
		"current_sophia_leagues":League.objects.filter(id__in=(Team.objects.filter(id__in=(Player.objects.filter(first_name="Sophia").values("curr_team"))).values("league"))),
		# ...everyone with the last name "Flores" who DOESN'T (currently) play for the Washington Roughriders
		"flores_not_curr_wa_rough":Player.objects.filter(last_name="Flores").exclude(curr_team__in=(Team.objects.filter(team_name="Washington Roughriders"))),
		# ...all teams, past and present, that Samuel Evans has played with
		"samuel_evans_teams":Team.objects.filter(id__in=(Player.objects.filter(first_name="Samuel", last_name="Evans").values("all_teams"))),
		# ...all players, past and present, with the Manitoba Tiger-Cats
		"tiger_cats_players":Player.objects.filter(all_teams__in=(Team.objects.filter(team_name="Tiger-Cats").values("id"))),
		# ...all players who were formerly (but aren't currently) with the Wichita Vikings
		"former_vikings":Player.objects.filter(all_teams__in=(Team.objects.filter(team_name="Vikings", location="Wichita").values("id"))).exclude(curr_team=(Team.objects.filter(team_name="Vikings", location="Wichita").values("id"))),
		# ...every team that Jacob Gray played for before he joined the Oregon Colts
		"jacob_gray_teams":Team.objects.exclude(team_name="Colts", location="Oregon").filter(id__in=(Player.objects.filter(first_name="Jacob",last_name="Gray").values("all_teams"))),
		# ...everyone named "Joshua" who has ever played in the Atlantic Federation of Amateur Baseball Players
		"joshua_afab_players":Player.objects.filter(first_name="Joshua").filter(all_teams__in=(Team.objects.filter(league__in=(League.objects.filter(name="Atlantic Federation of Amateur Baseball Players"))))),
		# ...all teams that have had 12 or more players, past and present. (HINT: Look up the Django annotate function.)
		"twleve_plus_teams":Team.objects.annotate(num_players=Count("all_players")).filter(num_players__gte=(12)),
		# ...all players, sorted by the number of teams they've played for
		"all_players_sorted":Player.objects.all().annotate(num_teams=Count("all_teams")).order_by("-num_teams"),
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")







