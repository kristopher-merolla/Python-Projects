# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class FullStackBooksConfig(AppConfig):
    name = 'full_stack_books'
